package com.fic.u3_helper;

public class Config
 {
    
    
         public String ServerEndpoint()
         {
          return  "http://localhost:8080/";
         }
            
        public String AssignmentSubmissionFHIRServer()
        {return
              "http://fhirserver.hl7fundamentals.org/fhir";
            }
        public String ValidationFHIRServer()
            {return
                  "http://wildfhir4.aegis.net/fhir4-0-1";
                }
    
        public String StudentId()
        {
             return "kaminker.diego@gmail.com";
            }
        public String StudentName()
        {return 
            "Diego Kaminker";    
        }
    
}
