package com.fic.u3_helper;

import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.MedicationRequest;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.util.ArrayList;

public class testrunner {

    public String L01_1_T01() {

        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String result = testhelper.getSearchParameterType(server, "Patient", "email");
        return result;
    }

    public String L01_1_T02() {

        String email = "john.mcenroe@tennis.com";
        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        Patient p;
        try {
            String url = "Patient?email=" + email;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();

            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public String L01_1_T03() {

        String email = "john.mcenroe@tennas.com";
        String result = "<<Not Existing>>";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        Patient p;
        try {
            String url = "Patient?email=" + email;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();
                if (result == "") {
                    result = "<<Not Existing>>";
                }
            }
        } catch (Exception e) {

            result = e.getMessage();
        }
        return result;

    }

    public String L01_2_T01() {
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String result = testhelper.getSearchParameterType(server, "Patient", "telecom");
        return result;
    }

    public String L01_2_T02() {

        String email = "john.mcenroe@tennis.com";
        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String system = "email";
        Patient p;
        try {
            String url = "Patient?telecom=" + system + "|" + email;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

    }

    public String L01_2_T03() {

        String email = "john.mcenroe@tennas.com";
        String result = "<<Not Existing>>";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String system = "email";
        Patient p;
        try {
            String url = "Patient?telecom=" + system + "|" + email;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

    }

    public String L01_2_T04() {

        String phone = "+12937774444";
        String result = "<<Not Existing>>";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String system = "phone";
        Patient p;
        try {
            String url = "Patient?telecom=" + system + "|" + phone;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

    }

    public String L01_2_T05() {

        String email = "dorothea.lange@photographer.com";
        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();

        Patient p;
        try {
            String url = "Patient?telecom=" + email;
            p = testhelper.SearchPatientByURL(server, url);
            if (p != null) {
                result = p.getNameFirstRep().getFamily() + " " + p.getNameFirstRep().getGivenAsSingleString();
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

    }

    private String InteractionCheck(String parameter) {

        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String result = testhelper.getInteraction(server, "Practitioner", parameter);
        return result;

    }

    private String ParameterTypeCheck(String parameter) {

        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        String result = testhelper.getSearchParameterType(server, "Practitioner", parameter);
        return result;

    }

    public String L02_1_T01() {

        String parameter = "name";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T02() {
        String parameter = "family";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T03() {
        String parameter = "given";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T04() {
        String parameter = "_id";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T05() {
        String parameter = "email";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T06() {
        String parameter = "telecom";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T07() {
        String parameter = "identifier";
        String result = ParameterTypeCheck(parameter);
        return result;
    }

    public String L02_1_T08() {
        String parameter = "birthdate";
        String result = ParameterTypeCheck(parameter);
        if (result=="") {result="<<not_supported>>";}
        return result;

    }

    public String L02_1_T09() {
        String parameter = "read";
        String result = InteractionCheck(parameter);
        return result;
    }

    public String L02_1_T10() {
        String parameter = "search-type";
        String result = InteractionCheck(parameter);
        return result;
    }
    public String L02_2_T01() {
        
        String id = "10";
        String result="<<Not Existing>>";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        Practitioner p;
        try {
            p = testhelper.PractitionerDirectGet(server,id);
            if (p!=null)
            {result=p.getNameFirstRep().getFamily()+" "+p.getNameFirstRep().getGivenAsSingleString();}
            } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
        
    
    }
    public String L02_2_T02() {
        
        String id = "1008";
        String result="<<Not Existing>>";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        Practitioner p;
        try {
            p = testhelper.PractitionerDirectGet(server,id);
            if (p!=null)
            {result=p.getNameFirstRep().getFamily()+" "+p.getNameFirstRep().getGivenAsSingleString();}
            } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }
    public String L02_2_T03() {
        
        String id = "9";
        String result="<<Not Existing>>";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        Practitioner p;
        try {
            p = testhelper.PractitionerDirectGet(server,id);
            if (p!=null)
            {result=p.getNameFirstRep().getFamily()+" "+p.getNameFirstRep().getGivenAsSingleString();}
            } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public String L02_3_T01() {
        
        String result="0:0";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
            }} catch (Exception e) {
            result = e.getMessage();
        }
        return result;
        
 
    }
    public String L02_3_T02A() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?family=Lennon";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
 
    }
    public String L02_3_T02B() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?family=McEnroe";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
        
 
    }
    public String L02_3_T03A() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?name=Lennon";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
 
    }
    public String L02_3_T03B() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?name=John";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
        
 
    }
    public String L02_3_T04A() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?gender=male";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
        
 
    }
    public String L02_3_T04B() {
        
        String result="";
        String server="";
        Config c=new Config();
        server=c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac =0;
        int CountPers =0;
        try {
            String url = "Practitioner?gender=female";
            pl = testhelper.SearchPractitionersByURL(server,url);
            for (Practitioner pra : pl) {
            {
                CountPers++;
                for (Identifier id : pra.getIdentifier())
                {
                    String system=id.getSystem();
                    if (system.endsWith("NPI"))
                    {
                        CountPrac++;
                       
                    }
                }
            }
            }
            Integer DifPers=(CountPers-CountPrac);
            result=String.valueOf(CountPers)+":"+String.valueOf(DifPers);
        
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
 
    }
    public String L02_4_T01A() {

        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?identifier=http://fhirintermediatecourse.org/NPI|54323";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public String L02_4_T01B() {

        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?identifier=http://fhirintermediatecourse.org/PP|241922";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
            }
            Integer DifPers = (CountPers - CountPrac);
            result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);

        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public String L02_4_T01C() {

        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?identifier=http://fhirintermediatecourse.org/NPI|9999999";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
            }
            Integer DifPers = (CountPers - CountPrac);
            result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);

        } catch (Exception e) {
            result = e.getMessage();
        }
        
        return result;

    }

    public String L02_4_T02A() {

        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?_id=10";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
            }
            Integer DifPers = (CountPers - CountPrac);
            result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);

        } catch (Exception e) {
            result = e.getMessage();
        }
        
        return result;

    }

    public String L02_4_T02B() {

        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?_id=9";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
            }
            Integer DifPers = (CountPers - CountPrac);
            result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);

        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }

    public String L02_4_T02C() {

        String result = "";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?_id=9932";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
            }
            Integer DifPers = (CountPers - CountPrac);
            result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);

        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }
    public String L02_5_T01A() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?email=john.mcenroe@tennis.com";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

      
    }
    public String L02_5_T01B() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?email=john.mcenroe@tennas.com";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
      
    }
    public String L02_5_T02A() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?telecom=phone|555-444-3333";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    
    }

    public String L02_5_T02B() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?telecom=email|john.mcenroe@tennis.com";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    
    }
    public String L02_5_T02C() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?telecom=email|john.mcenroe@tennas.com";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }
    public String L02_5_T02D() {
        String result = "0:0";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<Practitioner> pl;
        int CountPrac = 0;
        int CountPers = 0;
        try {
            String url = "Practitioner?telecom=john.mcenroe@tennis.com";
            pl = testhelper.SearchPractitionersByURL(server, url);
            for (Practitioner pra : pl) {
                {
                    CountPers++;
                    for (Identifier id : pra.getIdentifier()) {
                        String system = id.getSystem();
                        if (system.endsWith("NPI")) {
                            CountPrac++;

                        }
                    }
                }
                Integer DifPers = (CountPers - CountPrac);
                result = String.valueOf(CountPers) + ":" + String.valueOf(DifPers);
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    
    }
    public String RunTest(String WhichTest) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
    {
        String name=this.getClass().getName();
        String result="";
        Class<?> c = Class.forName(name);
        Method methods[] = c.getDeclaredMethods();
        for (Method meth : methods)
        {
            String testName=meth.getName();
            if (testName.equals(WhichTest))
            {
                testrunner other=new testrunner();
                try {
                result = meth.invoke(other).toString();
                }
                catch (Exception e)
                {
                    result=e.getMessage();
                }

            }
        }
        return result;
    }
    public ArrayList<String> AllTests() throws ClassNotFoundException
    {
        ArrayList<String> a = new ArrayList<String>();
        String name=this.getClass().getName();
        Class<?> c = Class.forName(name);
        Method methods[] = c.getDeclaredMethods();
        for (Method meth : methods)
        {
            String testName=meth.getName();

            if (Modifier.isPublic(meth.getModifiers()))
            { 
                String MyOwnName="AllTests";
                if (testName.equals(MyOwnName)==false)
                {
                    String MyRunner="RunTest";
                    if (testName.equals(MyRunner)==false)

                        {a.add(testName);}
                }
            }
        }
        return a;
    }

    public String L03_3_T01A() {

        String result = "OK";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<MedicationRequest> pl;
        try {
            String url = "MedicationRequest?_id=Mi0yOC0yMDIyMTAxMC0xMDQ5NjIz";
            pl = testhelper.SearchMedicationRequestByURL(server, url);
            if (pl.size()==1)
                {
                    String ValidationServerURL=c.ValidationFHIRServer();
                    MedicationRequest mr=pl.get(0);
                    FhirContext ctx = FhirContext.forR4();
                    IParser parser = ctx.newJsonParser();
                    String resourceText = parser.encodeResourceToString(mr);
                    
                    result=testhelper.ValidateResource(ValidationServerURL,resourceText);

                }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;

    }
    public String L03_3_T02A() {

        String result = "<<No Resource>>";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<MedicationRequest> pl;
        try {
            String url = "MedicationRequest?_id=Mi0yOC0yMDIyMTAxMC0xMDQ5NjIz";
            pl = testhelper.SearchMedicationRequestByURL(server, url);
            if (pl.size()==1)
                {
                    MedicationRequest mr=pl.get(0);
                    if (mr.hasRequester())

                    {
                        if (mr.getRequester().hasDisplay()) 
                        {result= mr.getRequester().getDisplay();}
                        else
                        {result="<<No requester.display Element>>";}
                    }
                    else
                    {result="<<No Requester>>";}
                }
        } catch (Exception e) {
            result = e.getMessage();
        }
        
        return result;

    }
    public String L03_3_T03A() {

        String result = "<<No Resource>>";
        String server = "";
        Config c = new Config();
        server = c.ServerEndpoint();
        ArrayList<MedicationRequest> pl;
        try {
            String url = "MedicationRequest?_id=Mi0yOC0yMDIyMTAxMC0xMDQ5NjIz";
            pl = testhelper.SearchMedicationRequestByURL(server, url);
            if (pl.size()==1)
                {
                    MedicationRequest mr=pl.get(0);
                    if (mr.hasDosageInstruction())

                    {
                        if (mr.getDosageInstruction().size()>1) 
                        {result= mr.getDosageInstruction().get(1).getText();}
                        else
                        {result="<<No Second Dosage Instruction>>";}
                    }
                    else
                    {result="<<No Dosage Instruction>>";}
                }
        } catch (Exception e) {
            result = e.getMessage();
        }
        
        return result;

    }

}