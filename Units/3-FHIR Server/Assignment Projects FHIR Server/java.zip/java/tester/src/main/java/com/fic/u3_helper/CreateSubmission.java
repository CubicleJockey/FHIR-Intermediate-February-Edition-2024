package com.fic.u3_helper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.time.*;

import org.hl7.fhir.r4.model.TestReport.TestReportResult;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.TestReport;
import org.hl7.fhir.r4.model.TestReport.SetupActionAssertComponent;
import org.hl7.fhir.r4.model.TestReport.TestReportActionResult;
import org.hl7.fhir.r4.model.TestReport.TestReportParticipantComponent;
import org.hl7.fhir.r4.model.TestReport.TestReportParticipantType;
import org.hl7.fhir.r4.model.TestReport.TestReportStatus;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;

public class CreateSubmission {

    public static Hashtable<String, String> RunTests() throws NoSuchMethodException, SecurityException,
            ClassNotFoundException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Hashtable<String, String> my_results = new Hashtable<String, String>();
        Hashtable<String, String> my_tests = new Hashtable<String, String>();
        testrunner t = new testrunner();
        ArrayList<String> tests = t.AllTests();
        for (int i = 0; i < tests.size(); i++) {
            my_tests.put(tests.get(i), "");
        }

        Set<String> keys = my_tests.keySet();

        // Obtaining iterator over set entries
        Iterator<String> itr = keys.iterator();

        // Displaying Key and value pairs
        while (itr.hasNext()) {
            String str = itr.next();
            String result = "";
            result = t.RunTest(str);
            
            if (result == null) {
                result = "";
            }
            my_results.put(str, result);
        }
        return my_results;
    }

    public static Hashtable<String, String> AddResults(Hashtable<String, String> overall,
            Hashtable<String, String> added

    ) {
        overall.putAll(added);
        return overall;
    }

    public static Hashtable<String, String> RunAllTests() throws NoSuchMethodException, SecurityException,
            ClassNotFoundException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Hashtable<String, String> overall_results = new Hashtable<String, String>();

        Hashtable<String, String> results = RunTests();
        overall_results = AddResults(results, results);

        return overall_results;
    }

    public static void main(String[] args) throws NoSuchMethodException, SecurityException, ClassNotFoundException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException {

        Hashtable<String, String> overall_results = RunAllTests();
        try {
            CreateTestReport(overall_results);
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }

    }

    private static void CreateTestReport(Hashtable<String, String> overall_results) {

        TestReport tr = new TestReport();
        Config c = new Config();
        tr.setResult(TestReportResult.PENDING);
        tr.setStatus(TestReportStatus.INPROGRESS);
        tr.getTestScript().setIdentifier(new Identifier().setSystem("http://fhirintermediate.org/test_script/id")
                .setValue("FHIR_INTERMEDIATE_U03-JAVA"));
        tr.setTester(c.StudentId());
        tr.setIssued(Date.from(Instant.now()));
        String datee = Instant.now().toString();
        datee = datee.replace("-", "");

        tr.getIdentifier().setSystem("http://fhirintermediate.org/test_report/id")
                .setValue(c.StudentId() + "_" + datee);
        TestReportParticipantComponent trps = new TestReportParticipantComponent();
        trps.setDisplay("Resource Server");
        trps.setUserData("Participant", c.StudentName());
        trps.setUri(c.ServerEndpoint());
        trps.setType(TestReportParticipantType.SERVER);
        tr.addParticipant(trps);

        List<String> tmp = Collections.list(overall_results.keys());
        Collections.sort(tmp);
        Iterator<String> itr = tmp.iterator();

        while (itr.hasNext()) {

            String str = itr.next();
            String result = overall_results.get(str);

            TestReport.TestReportTestComponent t = new TestReport.TestReportTestComponent();
            t.setDescription(str).setName(str).setId(str);

            SetupActionAssertComponent saac = new SetupActionAssertComponent();
            if (result != "") {
                saac.setResult(TestReportActionResult.PASS);
                saac.setMessage(result);
            } else {
                saac.setResult(TestReportActionResult.FAIL);
                saac.setMessage("Not Attempted");
            }

            t.addAction().setAssert(saac);

            tr.addTest(t);
        }

        FhirContext ctx = FhirContext.forR4();

        IParser p = ctx.newJsonParser();

        String filename = "FHIR_INTERMEDIATE_U3_SUBMISSION_" + c.StudentId() + "_" + datee + ".JSON";
        filename = filename.replace(":", "");
        filename = filename.replace("@", "");

        byte[] strToBytes = p.encodeResourceToString(tr).getBytes();
        try {
            FileOutputStream outputStream = new FileOutputStream(filename);
            outputStream.write(strToBytes);
            outputStream.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());

        }

    }

}