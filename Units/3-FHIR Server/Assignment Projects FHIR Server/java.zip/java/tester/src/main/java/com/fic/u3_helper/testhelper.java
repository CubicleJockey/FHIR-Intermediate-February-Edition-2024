package com.fic.u3_helper;

import java.util.ArrayList;
import java.util.Iterator;

import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CapabilityStatement;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.OperationOutcome;
import org.hl7.fhir.r4.model.Parameters;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.CapabilityStatement.CapabilityStatementRestComponent;
import org.hl7.fhir.r4.model.CapabilityStatement.CapabilityStatementRestResourceComponent;
import org.hl7.fhir.r4.model.CapabilityStatement.CapabilityStatementRestResourceSearchParamComponent;
import org.hl7.fhir.r4.model.CapabilityStatement.ResourceInteractionComponent;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.context.PerformanceOptionsEnum;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import ca.uhn.fhir.rest.client.api.ServerValidationModeEnum;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;

public class testhelper {
    public static String getInteraction(String server, String resource, String parameter) {
        String result = "";
        CapabilityStatement capa;
        try {
            capa = testhelper.GetCapabilityStatement(server);

            CapabilityStatementRestComponent rc = capa.getRest().iterator().next();
            if (rc != null) {
                Iterator<CapabilityStatementRestResourceComponent> rsresi = rc.getResource().iterator();
                CapabilityStatementRestResourceComponent rsres = rsresi.next();
                while (rsres != null) {
                    String myType = "";
                    if (rsres.hasType()) {
                        myType = rsres.getType().toString();
                    }
                    if (myType.equals(resource)) {
                        Iterator<ResourceInteractionComponent> inter = rsres.getInteraction().iterator();
                        if (inter != null) {
                            ResourceInteractionComponent ric = inter.next();
                            while (ric != null) {
                                if (ric.getCode().getDisplay() == parameter) {
                                    result = parameter;
                                    break;
                                }
                                if (inter.hasNext()) {
                                    ric = inter.next();
                                } else {
                                    ric = null;
                                }
                            }
                        }

                        break;
                    }
                    rsres = rsresi.next();
                }

            }
        } catch (Exception e) {

            result = e.getMessage();

        }

        return result;
    }

    public static String getSearchParameterType(String server, String resource, String parameter) {
        String result = "";
        CapabilityStatement capa;
        try {
            capa = testhelper.GetCapabilityStatement(server);

            CapabilityStatementRestComponent rc = capa.getRest().iterator().next();
            if (rc != null) {
                Iterator<CapabilityStatementRestResourceComponent> rsresi = rc.getResource().iterator();
                CapabilityStatementRestResourceComponent rsres = rsresi.next();
                while (rsres != null) {
                    String myType = "";
                    if (rsres.hasType()) {
                        myType = rsres.getType().toString();
                    }
                    if (myType.equals(resource)) {

                        Iterator<CapabilityStatementRestResourceSearchParamComponent> rsi = rsres.getSearchParam()
                                .iterator();
                        if (rsi != null) {
                            CapabilityStatementRestResourceSearchParamComponent rsp = rsi.next();

                            while (rsp != null) {
                                String MyParameter = "";
                                if (rsp.hasName())

                                {
                                    MyParameter = rsp.getName().toString();
                                }

                                if (MyParameter.equals(parameter)) {
                                    result = rsp.getType().toString();
                                    break;

                                }

                                else {
                                    if (rsi.hasNext()) {
                                        rsp = rsi.next();
                                    } else {
                                        rsp = null;
                                    }

                                }
                            }
                        }
                        break;
                    } else {
                        if (rsresi.hasNext()) {
                            rsres = rsresi.next();
                        } else {
                            rsres = null;
                        }
                    }
                }
            }
        } catch (Exception e) {

            result = e.getMessage();

        }
        if (result == null) {
            result = "";
        }
        return result;
    }

    private static CapabilityStatement GetCapabilityStatement(String server) throws Exception {
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        // Create a client
        IGenericClient client = ctx.newRestfulGenericClient(server);
        CapabilityStatement capa;
        try {

            capa = client.capabilities().ofType(CapabilityStatement.class).execute();
            return capa;

        } catch (Exception e) {
            throw (e);
        }

    }

    public static Patient SearchPatientByURL(String server, String url) throws Exception {
        // Create a context
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        // Create a client
        IGenericClient client = ctx.newRestfulGenericClient(server);
        Patient pa = null;
        try {

            Bundle bu = client.search()
                    .byUrl(url)
                    .returnBundle(Bundle.class)
                    .execute();

            for (Bundle.BundleEntryComponent entry : bu.getEntry()) {
                if (entry.getResource().fhirType().toString() == "Patient") {
                    pa = (Patient) entry.getResource();
                    break;
                }
            }
            if (pa != null) {
                return pa;
            } else {
                throw new ResourceNotFoundException("<<NOT EXISTING>>");
            }

        } catch (Exception e) {
            throw (e);
        }
    }

    public static ArrayList<Practitioner> SearchPractitionersByURL(String server, String url) throws Exception {
        // Create a context
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        // Create a client
        IGenericClient client = ctx.newRestfulGenericClient(server);
        ArrayList<Practitioner> pr = new ArrayList<Practitioner>();
        try {

            Bundle bu = client.search()
                    .byUrl(url)
                    .returnBundle(Bundle.class)
                    .execute();

            for (Bundle.BundleEntryComponent entry : bu.getEntry()) {
                if (entry.getResource().fhirType().toString() == "Practitioner") {
                    {
                        pr.add((Practitioner) entry.getResource());
                        
                    }
                }

            }
            return pr;
        } catch (Exception e) {
            throw (e);
        }
    }

    public static Practitioner PractitionerDirectGet(String server, String id) throws Exception {
        // Create a context
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        // Create a client
        IGenericClient client = ctx.newRestfulGenericClient(server);
        Practitioner pr = null;
        try {
            pr = client.read()
                    .resource(Practitioner.class)
                    .withId(id)
                    .execute();
            return pr;

        } catch (Exception e) {
            throw (e);
        }
    }

    public static ArrayList<MedicationRequest> SearchMedicationRequestByURL(String server, String url) throws Exception {
        // Create a context
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        // Create a client
        IGenericClient client = ctx.newRestfulGenericClient(server);
        ArrayList<MedicationRequest> pr = new ArrayList<MedicationRequest>();
        try {

            Bundle bu = client.search()
                    .byUrl(url)
                    .returnBundle(Bundle.class)
                    .execute();

            for (Bundle.BundleEntryComponent entry : bu.getEntry()) {
                if (entry.getResource().fhirType().toString() == "MedicationRequest") {
                    {
                        pr.add((MedicationRequest) entry.getResource());
                        
                    }
                }

            }
            return pr;
        } catch (Exception e) {
            throw (e);
        }
    }

    public static String ValidateResource(String ServerEndPoint,String resourceTextJson)
    {
        FhirContext ctx = FhirContext.forR4();
        ctx.getRestfulClientFactory().setServerValidationMode(ServerValidationModeEnum.NEVER);
        ctx.setPerformanceOptions(PerformanceOptionsEnum.DEFERRED_MODEL_SCANNING);
        IGenericClient client = ctx.newRestfulGenericClient(ServerEndPoint);
        IParser parser = ctx.newJsonParser();  
        MedicationRequest mr=parser.parseResource(MedicationRequest.class, resourceTextJson); 
        Parameters inParams = new Parameters();  
        {  
            inParams.addParameter().setName("resource").setResource(mr);  
        }  
    
        Parameters outParams = client  
            .operation()  
            .onType(MedicationRequest.class)  
            .named("$validate")  
            .withParameters(inParams)  
            .execute();  
    
     OperationOutcome oo = (OperationOutcome) outParams.getParameter().get(0).getResource();  

     String auxE="OK";
     if (oo.hasIssue())
            {
                auxE=oo.getIssueFirstRep().getDetails().getText();
                String sOk="All OK";
                if (auxE.equals(sOk))
                {
                    auxE="All OK";
                }
                else
                {
                    auxE="Error:"+oo.getIssueFirstRep().getDiagnostics();
                }
            }
            
     return auxE;
    }
   
}
