package com.fic.u3_test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;
@DisplayName("Tests for U3-L02_2:Practitioner - Direct Get (GetById)")
// T02) Direct Get a Practitioner resource by id [exists]
// T03) Direct Get a Practitioner resource by id [not exists]
// T04) Direct Get a Practitioner resource by id [exists, but it is not a practitioner]

public class L02_2_Tests {
    @Test
    @DisplayName("U3-L02_2_T01:Direct Get to an existing practitioner")
    void L02_2_T01() {
        
        testrunner t = new testrunner();
        String result=t.L02_2_T01();
        String ExpectedResult="MCENROE JOHN PATRICK";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
    @Test
    @DisplayName("U3-L02_2_T02:Direct Get to an non-existing practitioner")
    void L02_2_T02() {
        
        testrunner t = new testrunner();
        String result=t.L02_2_T02();
        String ExpectedResult="HTTP 404 NOT FOUND: HAPI-0971: RESOURCE PRACTITIONER/1008 IS NOT KNOWN";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
    @Test
    @DisplayName("U3-L02_2_T03:Direct Get to an existing person without NPI")
    void L02_2_T03() {
        
        testrunner t = new testrunner();
        String result=t.L02_2_T03();
        String ExpectedResult="HTTP 400 BAD REQUEST: THE PERSON YOU REQUESTED IS NOT A PRACTITIONER - LACKS A NPI IDENTIFIER";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
}
