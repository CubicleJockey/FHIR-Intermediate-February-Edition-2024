package com.fic.u3_test;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;

@DisplayName("Tests for U3-L02_3:Practitioner - Searches by Name & Gender")
// T01) No search parameters (getall) / All the persons have NPI identifier: should be 5
// T02) Search Practitioners by family / All the persons have NPI identifier: should be 1
// T03) Search Practitioners by name 
// T04) Search Practitioners by gender


public class L02_3_Tests {
    @Test
    @DisplayName("U3-L02_3_T01:Get All Practitioners - 5 found w/NPI")
    void L02_3_T01() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T01();
        String ExpectedResult="5:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T02A:Search All Practitioners by Family Name Lennon- None")
    void L02_3_T02A() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T02A();
        String ExpectedResult="0:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T02B:Search All Practitioners by Family Name = McEnroe- 1 match with NPI")
    void L02_3_T02B() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T02B();
        String ExpectedResult="1:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T03A:Search All Practitioners by Name = Lennon- None")
    void L02_3_T03A() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T03A();
 
        String ExpectedResult="0:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T03B:Search All Practitioners by Family Name = John- 3 match with NPI")
    void L02_3_T03B() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T03B();
 
        String ExpectedResult="3:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T04A:Search All male Practitioners : 5")
    void L02_3_T04A() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T04A();
        String ExpectedResult="5:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    @Test
    @DisplayName("U3-L02_3_T04B:Search All female Practitioners : 0")
    void L02_3_T04B() {
        
        testrunner t = new testrunner();
        String result=t.L02_3_T04B();
        String ExpectedResult="0:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
 
    }
    

}
