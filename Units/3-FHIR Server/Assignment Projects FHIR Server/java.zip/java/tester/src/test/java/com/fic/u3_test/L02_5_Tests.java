package com.fic.u3_test;

import static org.junit.jupiter.api.Assertions.assertEquals;


import com.fic.u3_helper.testrunner;
import org.junit.jupiter.api.*;


// T07a) Search Practitioners by _id [exists]
// T07b) Search Practitioners by _id [not exists]
// T09a) Search Practitioners by identifier [exists]
// T09b) Search Practitioners by identifier [not exists]
// T09c) Search Practitioners by identifier!=NPI [exception]
@DisplayName("Tests for U3-L02_5:Practitioner - Searches by Email and Telecom")

public class L02_5_Tests {
   
    @Test
    @DisplayName("U3-L02_5_T01A:Practitioner - Search by email - existing")
    void L02_5_T01A() {
        testrunner t = new testrunner();
        String result=t.L02_5_T01A();
        String ExpectedResult = "1:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

      
    }
    @Test
    @DisplayName("U3-L02_5_T01B:Practitioner / Search by email - not exists")
    void L02_5_T01B() {
        testrunner t = new testrunner();
        String result=t.L02_5_T01B();
        String ExpectedResult = "0:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

      
    }
    @Test
    @DisplayName("U3-L02_5_T02A:Practitioner / Search By telecom - phone / not supported")
    void L02_5_T02A() {
        testrunner t = new testrunner();
        String result=t.L02_5_T02A();
        String ExpectedResult="HTTP 501 NOT IMPLEMENTED: THE UNDERLYING SERVER ONLY HANDLES EMAIL ADDRESSES FOR THE PRACTITIONERS, THUS SEARCH BY SYSTEM=PHONE IS NOT IMPLEMENTED";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }

    @Test
    @DisplayName("U3-L02_5_T02B:Practitioner / Search By telecom - email / existing")
    void L02_5_T02B() {
        testrunner t = new testrunner();
        String result=t.L02_5_T02B();
        String ExpectedResult="1:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
    @Test
    @DisplayName("U3-L02_5_T02C:Practitioner / Search By telecom - email / not existing")
    void L02_5_T02C() {
        testrunner t = new testrunner();
        String result=t.L02_5_T02C();
        String ExpectedResult="0:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
    @Test
    @DisplayName("U3-L02_5_T02D:Practitioner / Search By telecom - w/o system / existing")
    void L02_5_T02D() {
        testrunner t = new testrunner();
        String result=t.L02_5_T02D();
        String ExpectedResult="1:0";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
    
}
