package com.fic.u3_test;

import static org.junit.jupiter.api.Assertions.assertEquals;



import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;

//U3-L01.1: Patient Resource / Add Support for search by email
// Tests for U3-L01.1
// T01) Retrieve server's metadata / Verify email as search parameter
// T02) Retrieve a Patient resource by email element [existing]
// T03) Retrieve a Patient resource by email element [not existing]

@DisplayName("Tests for U3-L01_1:Add Support for Searching Patient by Email")

public class L01_1_Tests {

    @Test
    @DisplayName("U3-L01_1_T01:Patient - verify email as search parameter in CapabilityStatement")
    void L01_1_T01() {
        String ExpectedResult = "string";
        testrunner t = new testrunner();
        String result=t.L01_1_T01();
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_1_T02:Patient - Search by email - existing")
    void L01_1_T02() {

        String ExpectedResult = "MCENROE JOHN PATRICK";
        testrunner t = new testrunner();
        String result=t.L01_1_T02();
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_1_T03:Patient - Search by email - Not Exists")
    void L01_1_T03() {

        String ExpectedResult = "<<Not Existing>>";
        testrunner t = new testrunner();
        String result=t.L01_1_T03();
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

}