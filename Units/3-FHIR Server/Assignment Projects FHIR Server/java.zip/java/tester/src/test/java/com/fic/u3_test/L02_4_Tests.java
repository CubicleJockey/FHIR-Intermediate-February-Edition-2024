package com.fic.u3_test;

import static org.junit.jupiter.api.Assertions.assertEquals;


import com.fic.u3_helper.testrunner;

import org.junit.jupiter.api.*;


// T07a) Search Practitioners by _id [exists]
// T07b) Search Practitioners by _id [not exists]
// T09a) Search Practitioners by identifier [exists]
// T09b) Search Practitioners by identifier [not exists]
// T09c) Search Practitioners by identifier!=NPI [exception]
@DisplayName("Tests for U3-L02_4:Practitioner - Searches by Id & Identifier")

public class L02_4_Tests {
    @Test
    @DisplayName("U3-L02_4_T01A:Search by identifier /  system=NPI - existing")
    void L02_4_T01A() {

        testrunner t = new testrunner();
        String result=t.L02_4_T01A();
        String ExpectedResult = "1:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

    @Test
    @DisplayName("U3-L02_4_T01B:Search by Identifier / but system not NPI")
    void L02_4_T01B() {

        testrunner t = new testrunner();
        String result=t.L02_4_T01B();
        String ExpectedResult = "HTTP 400 BAD REQUEST: PRACTITIONERS CAN ONLY BE FOUND KNOWING THE NPI IDENTIFIER - YOU ARE SPECIFYING : PP";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

    @Test
    @DisplayName("U3-L02_4_T01C:Search by identifier / NPI but does not exist")
    void L02_4_T01C() {
        testrunner t = new testrunner();
        String result=t.L02_4_T01C();
        String ExpectedResult = "0:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

    @Test
    @DisplayName("U3-L02_4_T02A:Search by _id : Existing Practitioner")
    void L02_4_T02A() {

        testrunner t = new testrunner();
        String result=t.L02_4_T02A();
        String ExpectedResult = "1:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

    @Test
    @DisplayName("U3-L02_4_T02B:Search by _id but the person is not a practitioner")
    void L02_4_T02B() {

        testrunner t = new testrunner();
        String result=t.L02_4_T02B();
        String ExpectedResult = "0:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

    @Test
    @DisplayName("U3-L02_4_T02C:Search by _id: non existing id")
    void L02_4_T02C() {

        testrunner t = new testrunner();
        String result=t.L02_4_T02C();
        String ExpectedResult = "0:0";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }

}
