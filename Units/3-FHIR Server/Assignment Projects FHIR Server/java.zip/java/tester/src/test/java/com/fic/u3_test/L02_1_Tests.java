package com.fic.u3_test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;

@DisplayName("Tests for U3-L02_1:Practitioner - Verify Interactions and All Search Parameters")
public class L02_1_Tests {
    // U3-L02.1: Support for Practitioner
    // Tests for U3-L02.1
    // T01a) Retrieve server's metadata / Verify support for search parameters for
    // Practitioner resources
    // T01b) Retrieve server's metadata / Verify support for searching Practitioner
    // resources
    // T02) Direct Get a Practitioner resource by id [exists]
    // T03) Direct Get a Practitioner resource by id [not exists]
    // T04) Direct Get a Practitioner resource by id [exists, but it is not a
    // practitioner]
    // T05a) Search Practitioners by Name [exists]
    // T05b) Search Practitioners by Name [not exists]
    // T06a) Search Practitioners by gender [exists]
    // T06b) Search Practitioners by gender [not exists]
    // T08a) Search Practitioners by family [exists]
    // T08b) Search Practitioners by family [not exists]
    // T07a) Search Practitioners by _id [exists]
    // T07b) Search Practitioners by _id [not exists]
    // T09a) Search Practitioners by identifier [exists]
    // T09b) Search Practitioners by identifier [not exists]
    // T09c) Search Practitioners by identifier!=NPI [exception]
    // T10a) Search Practitioners by email [exists]
    // T10b) Search Practitioners by email [not exists]
    // T11a) Search Practitioners by telecom [exists]
    // T11b) Search Practitioners by telecom [not exists]

    @Test
    @DisplayName("U3-L01_2_T01:metadata: Verify name as Search Param. for Practitioner ")
    void L02_1_T01() {
        String expected = "string";
        testrunner t = new testrunner();
        String result = t.L02_1_T01();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T02:metadata: Verify family as Search Param. for Practitioner ")
    void L02_1_T02() {
        String expected = "string";

        testrunner t = new testrunner();
        String result = t.L02_1_T02();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T03:metadata: Verify given as search parameter for Practitioner")
    void L02_1_T03() {
        String expected = "string";
        testrunner t = new testrunner();
        String result = t.L02_1_T03();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T04:metadata: Verify _id as search parameter for Practitioner")
    void L02_1_T04() {
        String expected = "token";
        testrunner t = new testrunner();
        String result = t.L02_1_T04();

        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T05:metadata: Verify email as search parameter for Practitioner")
    void L02_1_T05() {
        String expected = "string";
        testrunner t = new testrunner();
        String result = t.L02_1_T05();

        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T06:metadata: Verify telecom as search parameter for Practitioner")
    void L02_1_T06() {
        String expected = "token";
        testrunner t = new testrunner();
        String result = t.L02_1_T06();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T07:metadata: Verify identifier as search parameter for Practitioner")
    void L02_1_T07() {
        String expected = "token";
        testrunner t = new testrunner();
        String result = t.L02_1_T07();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T08:metadata: Verify birthdate is NOT a search parameter for Practitioner")
    void L02_1_T08() {
        String expected = "<<not_supported>>";
        testrunner t = new testrunner();
        String result = t.L02_1_T08();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T09:metadata: Verify Practitioner/read as Interaction")
    void L02_1_T09() {
        String expected = "read";
        testrunner t = new testrunner();
        String result = t.L02_1_T09();
        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T10:metadata: Verify Practitioner/search-type as Interaction")
    void L02_1_T10() {
        String expected = "search-type";
        testrunner t = new testrunner();
        String result = t.L02_1_T10();

        assertEquals(expected.toUpperCase(), result.toUpperCase());
    }
}
