package com.fic.u3_test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;

//U3-L01.2: Patient Resource / Add Support for search by telecom: system|value
//                             system: only 'email' or telecom=value
//          Error Message: a) If system!=email: 
//"The underlying server only handles email addresses for the patients, thus search by system="
//{system} + " is not implemented"
// Tests for U3-L01.2
// T01) Retrieve server's metadata / Verify telecom as search parameter
// T02) Retrieve a Patient resource by telecom element email|[existing]
// T03) Retrieve a Patient resource by telecom element email|[not existing]
// T04) Retrieve a Patient resource by telecom element phone|[something]: message a)
// T05) Retrieve a Patient resource by telecom element telecom|[existing]


@DisplayName("Tests for U3-L01_2:Add Support for Searching Patient by Telecom")

class L01_2_Tests {
    
    @Test
    @DisplayName("U3-L01_2_T01:Patient - Verify telecom as search parameter in CapabilityStatement")
    void L01_2_T01() {
        String ExpectedResult = "token";
        testrunner t = new testrunner();
        String result=t.L01_2_T01();
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());
    }

    @Test
    @DisplayName("U3-L01_2_T02:Patient - Search by telecom - existing")
    void L01_2_T02() {

        String ExpectedResult = "MCENROE JOHN PATRICK";
        testrunner t = new testrunner();
        String result=t.L01_2_T02();
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    }
    @Test
    @DisplayName("U3-L01_2_T03:Patient - Search by telecom / not exists")
    void L01_2_T03() {
        
        testrunner t = new testrunner();
        String result=t.L01_2_T03();
        String ExpectedResult="<<Not Existing>>";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
     
    }
    @Test
    @DisplayName("U3-L01_2_T04:Patient - Search by telecom / phone - not supported")
    void L01_2_T04() {
        
        testrunner t = new testrunner();
        String result=t.L01_2_T04();
        String ExpectedResult="HTTP 501 NOT IMPLEMENTED: THE UNDERLYING SERVER ONLY HANDLES EMAIL ADDRESSES FOR THE PATIENTS, THUS SEARCH BY SYSTEM=PHONE IS NOT IMPLEMENTED";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
   
    @Test
    @DisplayName("U3-L01_2_T05:Patient - Search by telecom w/o system")
    void L01_2_T05() {
        
        testrunner t = new testrunner();
        String result=t.L01_2_T05();
        String ExpectedResult="LANGE DOROTHEA";
        assertEquals(ExpectedResult.toUpperCase(),result.toUpperCase());
    
    }
   
}