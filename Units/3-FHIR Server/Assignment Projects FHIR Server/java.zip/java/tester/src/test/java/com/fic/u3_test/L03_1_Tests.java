package com.fic.u3_test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.*;
import com.fic.u3_helper.testrunner;

//*1 Make it FHIR compliant.  There are some elements missing.
//*2 Add the element Requester.display with the full name of the referenced requesting Practitioner
//*3 Add a new dosageInstruction if the medication being ordered is an opioid (The legacy API provides a function called IsOpioid( rxNormCode ) answering this question.

@DisplayName("Tests for U3-L03_1:MedicationRequest - Make it FHIR compliant")


public class L03_1_Tests {
    @Test
    @DisplayName("U3-L03_3_T01A:MedicationRequest - Direct Get - Validate")
    void L03_3_T01A() {

        testrunner t = new testrunner();
        String result=t.L03_3_T01A();
        String ExpectedResult = "All OK";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }
    @Test
    @DisplayName("U3-L03_3_T02A:MedicationRequest - Verify the display element for Requester")
    void L03_3_T02A() {

        testrunner t = new testrunner();
        String result=t.L03_3_T02A();
        String ExpectedResult = "Lewis Jerry";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }
    @Test
    @DisplayName("U3-L03_3_T03A:MedicationRequest - Verify added warning message for opioids")
    void L03_3_T03A() {

        testrunner t = new testrunner();
        String result=t.L03_3_T03A();
        String ExpectedResult = "WARNINGS - Limitations of use - Because of the risks associated with the use of opioids, [Product] should only be used in patients for whom other treatment options, including non-opioid analgesics, are ineffective, not tolerated or otherwise inadequate to provide appropriate management of pain";
        assertEquals(ExpectedResult.toUpperCase(), result.toUpperCase());

    }


}
