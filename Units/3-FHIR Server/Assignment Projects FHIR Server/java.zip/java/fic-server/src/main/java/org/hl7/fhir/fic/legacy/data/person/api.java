package org.hl7.fhir.fic.legacy.data.person;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hl7.fhir.fic.legacy.model.identifier;
import org.hl7.fhir.fic.legacy.model.person;
import org.hl7.fhir.fic.legacy.model.personidentifier;
import org.hl7.fhir.fic.legacy.model.rx;
import org.hl7.fhir.fic.legacy.model.meds;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class api {

    private List<person> PersonsList = null;
    private List<identifier> IdentifierList = null;
    private List<personidentifier> personIdentifierList = null;
    private List<rx> rxList = null;
    private List<meds> medsList = null;  
    private String personUrl = "http://3.221.164.25:9080/person";
    private String identifierUrl = "http://3.221.164.25:9080/identifier_type";
    private String personidentifierUrl = "http://3.221.164.25:9080/person_identifier";
    private String medsUrl = "http://3.221.164.25:9080/meds";
    private String rxUrl = "http://3.221.164.25:9080/rx";

    public void initialize(String baseUrl) {
    
       if (baseUrl!="")
        {
            personUrl = baseUrl + "/person";
            identifierUrl = baseUrl + "/identifier_type";
            personidentifierUrl = baseUrl + "/person_identifier";
            medsUrl = baseUrl + "/meds";
            rxUrl = baseUrl + "/rx";
            
        }
        
        GetAllLegacyPersons();
        GetAllLegacyIdentifiers();
        GetAllLegacyPersonIdentifier();
        GetAllLegacyRx();
        GetAllLegacyMeds();

    
    }
    public List<meds> Meds()
    {
        return medsList;
    }
    public List<rx> Rx()
    {
        return rxList;
    }
    public List<person> Persons()
    {
        return PersonsList;
    }

    public List<identifier> Identifiers()
    {
        return IdentifierList;
    }
    public List<personidentifier> PersonIdentifier()
    {
        return personIdentifierList;
    }
    private void GetAllLegacyRx()
    {
        URL qurl;
        rxList=new ArrayList<rx>();

        try {
            qurl = new URL(rxUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                String code = i.get("rxnorm_code").asText();
                String display = i.get("rxnorm_display").asText();
                String prescription_date = i.get("prescription_date").asText();
                String sig = i.get("sig").asText();
                Integer patient_id = Integer.parseInt(i.get("patient_id").asText());
                Integer prescriber_id = Integer.parseInt(i.get("prescriber_id").asText());
                rxList.add(new rx(code,display,sig,prescription_date,patient_id,prescriber_id));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }


    private void GetAllLegacyMeds()
    {
        URL qurl;
        medsList=new ArrayList<meds>();

        try {
            qurl = new URL(medsUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                String code = i.get("code").asText();
                String display = i.get("display").asText();
                String opioid = i.get("opioid").asText();
                medsList.add(new meds(code,display,opioid));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }

    private void GetAllLegacyPersonIdentifier() {
        URL qurl;
        personIdentifierList = new ArrayList<personidentifier>();

        try {
            qurl = new URL(personidentifierUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                int person_id = Integer.valueOf( i.get("prsn_id").asText());
                int identifier_id = Integer.valueOf(i.get("identifier_type_id").asText());
                String value = i.get("value").asText();
                personIdentifierList.add(new personidentifier(person_id, identifier_id, value));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }

    private void GetAllLegacyIdentifiers() {
        URL qurl;
        IdentifierList = new ArrayList<identifier>();

        try {
            qurl = new URL(identifierUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                int id = Integer.valueOf( i.get("identifier_type_id").asText());
                String code = i.get("identifier_code").asText();
                String desc = i.get("identifier_desc").asText();
                IdentifierList.add(new identifier(id, code, desc));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }

    private void GetAllLegacyPersons() {
        URL qurl;
        PersonsList = new ArrayList<person>();

        try {
            qurl = new URL(personUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                int id = Integer.valueOf( i.get("PRSN_ID").asText());
                String fname = i.get("PRSN_FIRST_NAME").asText();
                String sname = i.get("PRSN_SECOND_NAME").asText();
                String lname = i.get("PRSN_LAST_NAME").asText();
                String bdate = i.get("PRSN_BIRTH_DATE").asText();
                String gender = i.get("PRSN_GENDER").asText();
                String email = i.get("PRSN_EMAIL").asText();
                String nick = i.get("PRSN_NICKNAME").asText();
                person p = new person(id, fname, sname, lname, bdate, gender, email, nick);
                PersonsList.add(p);
            }
        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }

    
    public static JsonNode get(URL url) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readTree(url);

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

