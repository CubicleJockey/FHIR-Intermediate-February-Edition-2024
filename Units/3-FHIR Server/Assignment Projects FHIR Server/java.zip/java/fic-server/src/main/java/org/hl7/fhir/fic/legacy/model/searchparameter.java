package org.hl7.fhir.fic.legacy.model;

public class searchparameter {
    
    public enum SearchBy{

        ID,
        FIRST_NAME,
        SECOND_NAME,
        LAST_NAME,
        BIRTH_DATE,
        GENDER,
        EMAIL,
        NAME,
        IDENTIFIER,
        PATIENT,
        INTENT,
        AUTHOREDON,
        STATUS

        
    }
    private SearchBy parametername;
    private String parametervalue;
    public SearchBy getname() { return parametername; }
	public String getvalue() { return parametervalue; }
	
	
	public searchparameter(SearchBy name, String value) {

		parametername=name;
        parametervalue=value;
    }
}
