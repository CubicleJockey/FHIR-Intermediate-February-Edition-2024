package org.hl7.fhir.fic.legacy.data.person;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hl7.fhir.fic.legacy.config.config;
import org.hl7.fhir.fic.legacy.model.identifier;
import org.hl7.fhir.fic.legacy.model.person;
import org.hl7.fhir.fic.legacy.model.personidentifier;
import org.hl7.fhir.fic.legacy.model.searchparameter;
import org.hl7.fhir.fic.legacy.model.searchparameter.SearchBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class personActions {

    private List<person> PersonsList = null;
    private List<identifier> IdentifierList = null;
    private List<personidentifier> personIdentifierList = null;
    private static final Logger LOGGER = LoggerFactory.getLogger( personActions.class);
    public personActions(String baseUrl)
    {
        api a = new api();
        if (baseUrl=="")
        {
            config c=new config();
            baseUrl=c.Url();
            
            LOGGER.info("Legacy API @ " + baseUrl);

        }
        a.initialize(baseUrl);
        PersonsList=a.Persons();
        IdentifierList=a.Identifiers();
        personIdentifierList=a.PersonIdentifier();
        
    }
    public String GetIdentifierTypeCode(int identifier_type_id)
    {
        String code="";
        for (identifier id : IdentifierList)
        {
                if (id.getId()==identifier_type_id)
                {
                    code=id.getCode();
                }
        }
        return code;
    }
    public List<personidentifier> IdentifierPersonList(int person_id)
    {
        List<personidentifier> l= new ArrayList<personidentifier>();
        for (personidentifier pi : personIdentifierList) {
            
            if (pi.getPersonId()==person_id)
            {
                
                l.add(new personidentifier(pi.getPersonId(),pi.getIdentifierId(),pi.getIdentifierValue()));
            }
        }
        return l;
     
    }
    
    public List<person> read(
            String theId) {
    
    
        // List<patientStructure> SearchList=new ArrayList<patientStructure>();
        // return SearchList;
        List<searchparameter> lp=new ArrayList<searchparameter>();
        lp.add(new searchparameter(SearchBy.ID,theId));
        return search(lp);

    }
    
    public List<person> search(
            List<searchparameter> SearchParameters
            ) {
        
        List<person> SearchList=new ArrayList<person>();
        for (person p : PersonsList) {

            boolean match=true;
            
            for (searchparameter s : SearchParameters) {
                String value=s.getvalue();
                switch  (s.getname())
                {
                case BIRTH_DATE:
                
                    String[] splitted=value.split("\\|");
                    SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
                    try {
                        Date dFrom = sdformat.parse(splitted[0]);
                        Date dTo = sdformat.parse(splitted[1]);
                        Date dPer = sdformat.parse(p.getBirthDate());
                        match=match && ((dPer.compareTo(dFrom)>=0) 
                        && (dPer.compareTo(dTo)<=0));
                    } catch (ParseException e) {
                        match=false;
                     }
                
                        
                    break;
                case EMAIL:
                    String MyEmail=p.getEmail();  
                    match=match && MyEmail.equalsIgnoreCase(value);
                    break;
            
                case FIRST_NAME:
                    
                    boolean fi= org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getFirstName(),value);
                    boolean se= org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getSecondName(),value);
                    match = match && (fi || se);
                    
                    break;
                case GENDER:
                    
                    match = match && org.apache.commons.lang3.StringUtils.equalsIgnoreCase(p.getGender(), value);
                    break;
                
                case ID:
                    try {
                        int IdWanted=Integer.parseInt(value);
                        int IdPerson=p.getId();
                        match = match && (IdWanted==IdPerson);
        
                    } catch (Exception e) {
                        match= false;
                    } 
                    
                break;
                case IDENTIFIER:
                String[] id_splitted=value.split("\\|");
                String id_system = id_splitted[0];
                String id_value= "";
                
                if (id_splitted.length>1)
                {
                    id_value  = id_splitted[1];
                }
                List<personidentifier> lpi = IdentifierPersonList(p.getId());
                boolean oneMatch=false;
                for (personidentifier pi : lpi) {
                    boolean ValueMatch=true;
                    boolean SystemMatch=true;
                    if (id_value!="")
                    {
                        String MyValue=pi.getIdentifierValue();
                        ValueMatch =MyValue.equals(id_value);
                    }
                    if (id_system!="")
                    {
                        String systemcode = GetIdentifierTypeCode( pi.getIdentifierId());
                        SystemMatch=systemcode.equals(id_system);
                    }
                    
                    oneMatch = (SystemMatch && ValueMatch);
                    //One match in the list of identifiers for the person & I am good to go
                    if (oneMatch==true){break;}
                
                }   
                match = match && oneMatch;  
                break;
                case LAST_NAME:
                    match = match && org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getLastName(),value);
                    
                break;
                case NAME:
                    boolean las = org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getLastName(),value);
                    boolean fir = org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getFirstName(),value);
                    boolean sec = org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getSecondName(),value);
                    boolean nic = org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getNickName(),value);
                    
                    match = match &&  ( las || fir || sec || nic);
                    
                    break;
                case SECOND_NAME:
                    match = match && org.apache.commons.lang3.StringUtils.containsIgnoreCase(p.getSecondName(),value);
                    break;
                default:
                    
                }

            if (match==false) break;
            }
            if (match==true){
                
                SearchList.add(p);
                
            }
            

        }

        return SearchList;
        
    }

}
