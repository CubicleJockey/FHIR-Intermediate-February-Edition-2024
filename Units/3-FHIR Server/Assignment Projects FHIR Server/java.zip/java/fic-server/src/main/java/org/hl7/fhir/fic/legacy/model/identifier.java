package org.hl7.fhir.fic.legacy.model;

public class identifier {
    private int identifier_type_id;
	private String identifier_code;
    private String identifier_desc;
    
	public int getId() { return identifier_type_id; }
	public String getCode() { return identifier_code; }
	public String getDescription() { return identifier_desc; }
	
	public identifier(int iD, String code, String desc) {
		identifier_type_id = iD;
        identifier_code = code;
        identifier_desc = desc;
    }
}
