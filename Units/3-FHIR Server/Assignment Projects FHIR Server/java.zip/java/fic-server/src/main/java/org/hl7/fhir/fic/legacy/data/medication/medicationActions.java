package org.hl7.fhir.fic.legacy.data.medication;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.DatatypeConverter;

import org.hl7.fhir.fic.legacy.config.config;
import org.hl7.fhir.fic.legacy.model.searchparameter;
import org.hl7.fhir.fic.legacy.model.searchparameter.SearchBy;
import org.hl7.fhir.fic.legacy.model.rx;
import org.hl7.fhir.fic.legacy.model.meds;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;



public class medicationActions {

    private List<rx> rxList = null;
    private List<meds> medsList = null;
    //private static final Logger LOGGER = LoggerFactory.getLogger( medicationActions.class);
    public medicationActions(String baseUrl)
    {
        api a = new api();
        if (baseUrl=="")
        {
            config c=new config();
            baseUrl=c.Url();
            
         
        }
        a.initialize(baseUrl);
        medsList=a.Meds();
        rxList = a.Rx();
        
    }
    public List<rx> read(
            String theId) {
    
    
        List<searchparameter> lp=new ArrayList<searchparameter>();
        lp.add(new searchparameter(SearchBy.ID,theId));
        return search(lp);

    }
    
    public List<rx> search(List<searchparameter> searchParameters)
    {

        List<rx> SearchList=new ArrayList<rx>();
        for (rx p : rxList) {

            boolean match=true;
            for (searchparameter s : searchParameters) {
                String value=s.getvalue();
                switch  (s.getname())
                {
                case INTENT:
                    //default value for intent in our EHR: order, any other is not include
                    String defaultIntent="order";
                    if (value.equals(defaultIntent)==false)
                    {match=false;}
                    break;

                case STATUS:
                //default value for status in our EHR: active, any other is not include
                    
                    String defaultStatus="active";
                    if (value.equals(defaultStatus)==false)
                    {match=false;}
                    break;

                case PATIENT:
                    String patient_id=p.getPatientId().toString();
                    if (value.equals(patient_id)==false)
                    {match=false;}
                    break;
                case ID:
                    String f_patientId=p.getPatientId().toString();
                    String f_prescriberId = p.getPrescriberId().toString();
                    String f_PrescriptionDate = p.getPrescriptionDate().toString();
                    String f_RxNormCode = p.getRxNorm_Code().toString();
                    
                    String medreq_id=GetFantasyId(f_patientId,f_prescriberId,f_PrescriptionDate,f_RxNormCode);
                    if (value.equals(medreq_id)==false)
                    {match=false;}
                    break;
                case AUTHOREDON:    
                    String[] splitted=value.split("\\|");
                    SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
                    try {
                        Date dFrom = sdformat.parse(splitted[0]);
                        Date dTo = sdformat.parse(splitted[1]);
                        Date dPer = sdformat.parse(p.getPrescriptionDate());
                        match=match && ((dPer.compareTo(dFrom)>=0) 
                        && (dPer.compareTo(dTo)<=0));
                    } catch (ParseException e) {
                        match=false;
                    }
                
                    
                    break;
                default:
                }
                if (match==false) break;
            }
         
            if (match==true){
                
                SearchList.add(p);
                
            }
            

        }

        return SearchList;
        
    }
    public Boolean IsOpioid(String RxNormCode)
    {
        Boolean IsOpi = false;
        for (meds p : medsList) {
                String code=p.getCode();
                if (code.equals(RxNormCode))
                {
                    IsOpi=p.isOpioid();
                    break;
                }
        }
        return IsOpi;
    }
    public String GetFantasyId(String PatId,String PreId, String PreDate, String RxNormCode)
    {
        String ComposedId = 
         PatId + "-" +
         PreId.toString() + "-" +
        PreDate.replace("-","") + "-" +
        RxNormCode;
        String ComposedIdB64 = DatatypeConverter.printBase64Binary(ComposedId.getBytes());
        ComposedIdB64=ComposedIdB64.replace("=", ".");
        return ComposedIdB64;

    }


}

