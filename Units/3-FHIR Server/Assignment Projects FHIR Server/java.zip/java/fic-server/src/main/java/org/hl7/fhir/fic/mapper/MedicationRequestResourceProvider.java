package org.hl7.fhir.fic.mapper;

import org.hl7.fhir.fic.legacy.data.medication.medicationActions;
import org.hl7.fhir.fic.legacy.data.person.personActions;
import org.hl7.fhir.fic.legacy.model.person;
import org.hl7.fhir.fic.legacy.model.rx;
import org.hl7.fhir.fic.legacy.model.searchparameter;
import org.hl7.fhir.fic.legacy.model.searchparameter.SearchBy;

import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Dosage;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class MedicationRequestResourceProvider implements IResourceProvider {

    @Autowired

    private medicationActions legacyMedication = new medicationActions("");
    private personActions legacyPerson = new personActions("");

    @Override
    public Class<? extends IBaseResource> getResourceType() {
        return MedicationRequest.class;
    }

    @Search
    public List<Resource> searchMedicationRequest(HttpServletRequest request,
            @OptionalParam(name = MedicationRequest.SP_AUTHOREDON) DateRangeParam authoredOn,
            @OptionalParam(name = MedicationRequest.SP_STATUS) StringParam status,
            @OptionalParam(name = MedicationRequest.SP_PATIENT) StringParam patient,
            @OptionalParam(name = MedicationRequest.SP_INTENT) StringParam intent,
            @OptionalParam(name = MedicationRequest.SP_RES_ID) StringParam resid
            ) {
        List<searchparameter> spar = new ArrayList<searchparameter>();
        if (authoredOn != null) {
            String upper = "9998-12-31";
            String lower = "1753-01-01";
            if (authoredOn.getLowerBound() != null) {
                lower = authoredOn.getLowerBound().getValueAsString();
            }
            ;
            if (authoredOn.getUpperBound() != null) {
                upper = authoredOn.getUpperBound().getValueAsString();
            }
            ;
            spar.add(new searchparameter(SearchBy.AUTHOREDON, lower + "|" + upper));
        }
        if (status != null) {
            spar.add(new searchparameter(SearchBy.STATUS, status.getValue()));
        }
        if (intent != null) {
            spar.add(new searchparameter(SearchBy.INTENT, intent.getValue()));
        }
        if (patient != null) {
            spar.add(new searchparameter(SearchBy.PATIENT, patient.getValue()));
        }
        if (resid != null) {
            spar.add(new searchparameter(SearchBy.ID, resid.getValue()));
        }

        List<rx> l = legacyMedication.search(spar);
        return AssembleResources(l);

    }

    public List<Resource> AssembleResources(List<rx> l) {
        List<Resource> lr = new ArrayList<Resource>();
        for (rx r : l) {
            MedicationRequest fmr = new MedicationRequest();
            try {
                Date bd = new SimpleDateFormat("yyyy-MM-dd").parse(r.getPrescriptionDate());
                fmr.setAuthoredOn(bd);

             
                CodeableConcept cc = new CodeableConcept();
                Coding co = new Coding("http://www.nlm.nih.gov/research/umls/rxnorm", r.getRxNorm_Code(),
                        r.getRxNorm_Display());
                cc.addCoding(co);
                fmr.setMedication(cc);
              
                org.hl7.fhir.r4.model.Reference refPat = new org.hl7.fhir.r4.model.Reference();
                refPat.setReference("Patient/" +r.getPatientId().toString() );
                
                IdType tid = new IdType();
                tid.setValue(refPat.getReference());
                String stringTheId = tid.getIdPart();
        
                List<person> pl= legacyPerson.read(stringTheId);
                if (pl.size()>0)
                {
                    person pe=pl.get(0);
                    String Fullname=pe.getLastName()+" "+pe.getFirstName().toString();
                    if (pe.getSecondName()!="")
                    { Fullname=Fullname+ " "+pe.getSecondName();}
                    refPat.setDisplay(Fullname);
                }

                fmr.setSubject(refPat);

                org.hl7.fhir.r4.model.Reference refPra = new org.hl7.fhir.r4.model.Reference();
                refPra.setReference("Practitioner/" + r.getPrescriberId().toString());
                fmr.setRequester(refPra);
                
                
                String f_patientId=r.getPatientId().toString();
                String f_prescriberId = r.getPrescriberId().toString();
                String f_PrescriptionDate = r.getPrescriptionDate().toString();
                String f_RxNormCode = r.getRxNorm_Code().toString();
                String FantasyId = legacyMedication.GetFantasyId(f_patientId,f_prescriberId,f_PrescriptionDate,f_RxNormCode);
                fmr.setId(FantasyId);

                if (r.getSig() != null) {
                    Dosage sig1 = new Dosage();
                    sig1.setText(r.getSig().toString());
                    fmr.addDosageInstruction(sig1);
                }
                
              
                lr.add(fmr);

            } catch (ParseException e) {
            }
        }
        return lr;

    }

    @Read()
    public MedicationRequest read(@IdParam IdType theId) {

        String stringTheId = theId.getIdPart();
        List<rx> l = legacyMedication.read(stringTheId);
        List<Resource> lr = AssembleResources(l);
        if (lr.size() > 0) {
            return (MedicationRequest) lr.get(0);
        } else {
            throw new ResourceNotFoundException(theId);
        }

    }

    @Search()
    public List<Resource> getAllRxs() {

        List<searchparameter> spar = new ArrayList<searchparameter>();
        List<rx> l = legacyMedication.search(spar);
        return AssembleResources(l);

    }

}

