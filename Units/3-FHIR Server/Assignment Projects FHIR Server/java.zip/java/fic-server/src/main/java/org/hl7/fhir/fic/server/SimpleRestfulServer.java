package org.hl7.fhir.fic.server;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import org.hl7.fhir.fic.mapper.MedicationRequestResourceProvider;
import org.hl7.fhir.fic.mapper.PatientResourceProvider;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.server.RestfulServer;
import ca.uhn.fhir.rest.server.interceptor.ResponseHighlighterInterceptor;

@WebServlet("/*")
public class SimpleRestfulServer extends RestfulServer {

	@Override
	protected void initialize() throws ServletException {
		// Create a context for the appropriate version
		setFhirContext(FhirContext.forR4());
		
		// Register resource providers
		registerProvider(new PatientResourceProvider());
		registerProvider(new MedicationRequestResourceProvider());
		
		// Format the responses in  HTML
		registerInterceptor(new ResponseHighlighterInterceptor());
	}
}
