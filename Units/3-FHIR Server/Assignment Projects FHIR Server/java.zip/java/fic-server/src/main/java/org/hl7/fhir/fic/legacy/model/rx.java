package org.hl7.fhir.fic.legacy.model;

public class rx {
   
    private String rxnorm_code;
	private String rxnorm_display;
    private String sig;
    private String prescription_date;
    private Integer patient_id;
    private Integer prescriber_id;
    public String getRxNorm_Code() { return rxnorm_code; }
	public String getRxNorm_Display() { return rxnorm_display; }
    public String getSig() { return sig; }
	public String getPrescriptionDate() {return prescription_date;}
    public Integer getPatientId() {return patient_id;}
    public Integer getPrescriberId() {return prescriber_id;}
    
	
    public rx( String Rxnorm_code, String Rxnorm_display, String Sig, String Prescription_date,
    Integer Patient_id, Integer Prescriber_id)
     {
        rxnorm_code=Rxnorm_code;
        rxnorm_display=Rxnorm_display;
        prescription_date=Prescription_date;
        patient_id=Patient_id;
        prescriber_id=Prescriber_id;
        sig=Sig;
     }
	
}
