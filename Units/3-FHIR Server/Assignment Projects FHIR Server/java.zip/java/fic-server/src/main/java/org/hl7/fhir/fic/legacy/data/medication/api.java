package org.hl7.fhir.fic.legacy.data.medication;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hl7.fhir.fic.legacy.model.rx;
import org.hl7.fhir.fic.legacy.model.meds;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class api {

    private List<rx> rxList = null;
    private List<meds> medsList = null;  
    private String medsUrl = "http://3.221.164.25:9080/meds";
    private String rxUrl = "http://3.221.164.25:9080/rx";
    private static final Logger LOGGER = LoggerFactory.getLogger( medicationActions.class);
    
    public void initialize(String baseUrl) {
    
       if (baseUrl!="")
        {
            medsUrl = baseUrl + "/meds";
            rxUrl = baseUrl + "/rx";
            
        }
        
        GetAllLegacyRx();
        GetAllLegacyMeds();

    
    }
    public List<meds> Meds()
    {
        return medsList;
    }
    public List<rx> Rx()
    {
        return rxList;
    }
    private void GetAllLegacyRx()
    {
        URL qurl;
        rxList=new ArrayList<rx>();

        try {
            qurl = new URL(rxUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                String code = i.get("rxnorm_code").asText();
                String display = i.get("rxnorm_display").asText();
                String prescription_date = i.get("prescription_date").asText();
                String sig = i.get("sig").asText();
                Integer patient_id = Integer.parseInt(i.get("patient_id").asText());
                Integer prescriber_id = Integer.parseInt(i.get("prescriber_id").asText());
                rxList.add(new rx(code,display,sig,prescription_date,patient_id,prescriber_id));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }


    private void GetAllLegacyMeds()
    {
        URL qurl;
        medsList=new ArrayList<meds>();
        
        try {
            LOGGER.info("Legacy RX API @ " + medsUrl);
            qurl = new URL(medsUrl);
            JsonNode j = get(qurl);
            Iterator<JsonNode> itr = j.elements();
            while (itr.hasNext()) {
                JsonNode i = itr.next();
                String code = i.get("code").asText();
                String display = i.get("display").asText();
                String opioid = i.get("opioid").asText();
                medsList.add(new meds(code,display,opioid));
            }

        } catch (MalformedURLException e) {

            e.printStackTrace();
        }

    }

    
    public static JsonNode get(URL url) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readTree(url);

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

