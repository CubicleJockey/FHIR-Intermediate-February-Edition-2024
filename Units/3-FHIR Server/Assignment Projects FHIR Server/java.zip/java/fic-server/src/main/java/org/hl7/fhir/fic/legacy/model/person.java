package org.hl7.fhir.fic.legacy.model;

public class person {
    

    private int PRSN_ID;
	private String PRSN_FIRST_NAME;
    private String PRSN_SECOND_NAME;
    private String PRSN_LAST_NAME;
	private String PRSN_BIRTH_DATE;
	private String PRSN_GENDER;
	private String PRSN_EMAIL;
    private String PRSN_NICKNAME;
	
	public int getId() { return PRSN_ID; }
	public String getFirstName() { return PRSN_FIRST_NAME; }
	public String getSecondName() { return PRSN_SECOND_NAME; }
	public String getLastName() { return PRSN_LAST_NAME; }
	public String getBirthDate() { return PRSN_BIRTH_DATE; }
	public String getGender() { return PRSN_GENDER;}
	public String getEmail() {return PRSN_EMAIL;}
	public String getNickName() {return PRSN_NICKNAME;}

	public person(int iD, String fIRST_NAME, String sECOND_NAME, String lAST_NAME, String bIRTH_DATE,
			String gENDER, String eMAIL, String nICKNAME) {
		PRSN_ID = iD;
		PRSN_FIRST_NAME = fIRST_NAME;
		PRSN_SECOND_NAME = sECOND_NAME;
		PRSN_LAST_NAME = lAST_NAME;
		PRSN_BIRTH_DATE = bIRTH_DATE;
		PRSN_GENDER = gENDER;
		PRSN_EMAIL = eMAIL;
		PRSN_NICKNAME = nICKNAME;
	}
	
}
