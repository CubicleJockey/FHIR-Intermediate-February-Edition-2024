package org.hl7.fhir.fic.mapper;

import org.hl7.fhir.fic.legacy.config.config;
import org.hl7.fhir.fic.legacy.data.person.personActions;
import org.hl7.fhir.fic.legacy.model.person;
import org.hl7.fhir.fic.legacy.model.personidentifier;
import org.hl7.fhir.fic.legacy.model.searchparameter;
import org.hl7.fhir.fic.legacy.model.searchparameter.SearchBy;

import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.ContactPoint;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ContactPoint.ContactPointSystem;
import org.hl7.fhir.r4.model.Enumerations.AdministrativeGender;
import org.hl7.fhir.r4.model.HumanName.NameUse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class PatientResourceProvider implements IResourceProvider {



    @Autowired
    
    private personActions legacyPerson=new personActions("");
    
    @Override
    public Class<? extends IBaseResource> getResourceType() {
        return  Patient.class;
    }

    @Search
    public List<Resource> searchPatient(HttpServletRequest request,
                                        @OptionalParam(name= Patient.SP_BIRTHDATE) DateRangeParam birthDate,
                                        @OptionalParam(name = Patient.SP_FAMILY) StringParam familyName,
                                        @OptionalParam(name= Patient.SP_GENDER) StringParam gender,   
                                        @OptionalParam(name= Patient.SP_GIVEN) StringParam givenName,
                                        @OptionalParam(name = Patient.SP_IDENTIFIER) TokenParam identifier,
                                        @OptionalParam(name= Patient.SP_NAME) StringParam name,
                                        @OptionalParam(name = Patient.SP_RES_ID) TokenParam resid) 
    {
        List<searchparameter> spar = new ArrayList<searchparameter>();
        if (birthDate!=null) 
        {
            String upper="9998-12-31";
            String lower="1753-01-01";
            if (birthDate.getLowerBound()!=null){ lower=birthDate.getLowerBound().getValueAsString();};
            if (birthDate.getUpperBound()!=null){ upper=birthDate.getUpperBound().getValueAsString();};
            spar.add(new searchparameter(SearchBy.BIRTH_DATE, lower+"|"+upper));
        }
        if (familyName!=null)
        {
            spar.add(new searchparameter(SearchBy.LAST_NAME, familyName.getValue()));
        }
        if (givenName!=null)
        {
            spar.add(new searchparameter(SearchBy.FIRST_NAME, givenName.getValue()));
        }
        if (identifier!=null)
        {
            String system=identifier.getSystem();
            if (system==null) {system="";}
            config c=new config();
            String uribase=c.IdentifierUri()+"/";
            system = system.replace(uribase,"");
            
            String value =identifier.getValue();
            spar.add(new searchparameter(SearchBy.IDENTIFIER, system+"|"+value));
        }
        if (resid!=null)
        {
            spar.add(new searchparameter(SearchBy.ID, resid.getValue()));
        }
        if (name!=null)
        {
            spar.add(new searchparameter(SearchBy.NAME, name.getValue()));
        }
        if (gender!=null)
        {
            spar.add(new searchparameter(SearchBy.GENDER, gender.getValue()));
        }
        List<person> l= legacyPerson.search(spar);
        return AssembleResources(l);

    }
    
    public List<Resource> AssembleResources(List<person> l)
    {
      List<Resource> lr = new ArrayList<Resource>();
      config c=new config();
      String uri=c.IdentifierUri();
      for (person p : l) {
        Patient fp=new Patient();
        fp.setId(String.valueOf(p.getId()));
        HumanName hn=new HumanName();
        hn.setFamily(p.getLastName());
        hn.addGiven(p.getFirstName());
        if (p.getSecondName()!="")
        {
            hn.addGiven(p.getSecondName());
        }
        fp.addName(hn);
        hn.setUse(NameUse.OFFICIAL);
        if (p.getNickName()!="")
        {
            HumanName nn=new HumanName();
            fp.addName(nn);
            nn.setText(p.getNickName());
            nn.setUse(NameUse.NICKNAME);
        }
        try {
            Date bd = new SimpleDateFormat("yyyy-MM-dd").parse(p.getBirthDate());
            fp.setBirthDate(bd);
        } catch (ParseException e) {
            
        }
        String gnd=p.getGender();
        fp.setGender(AdministrativeGender.fromCode(gnd));
        ContactPoint tt=new ContactPoint();
        tt.setSystem(ContactPointSystem.EMAIL);
        tt.setValue(p.getEmail());
        fp.addTelecom(tt);
        lr.add(fp); 
        List<personidentifier> ipl = legacyPerson.IdentifierPersonList(p.getId());
        for(personidentifier pi:ipl)
        {
            Identifier nidt= new Identifier();
            String code =  legacyPerson.GetIdentifierTypeCode(pi.getIdentifierId());
            nidt.setValue(pi.getIdentifierValue());
            nidt.setSystem(uri +"/" + code);
            fp.addIdentifier(nidt);
        }
      }
      return lr;
    }
    @Read()
    public Patient read(@IdParam IdType theId) {

        String stringTheId = theId.getIdPart();
        List<person> l = legacyPerson.read(stringTheId);
        List<Resource> lr = AssembleResources(l);
        if (lr.size()>0)
        {    return (Patient)lr.get(0);}
        else
        {
            throw new ResourceNotFoundException(theId);
        }
        
            


    }

   
    @Search()
    public List<Resource> getAllPatients() {

        List<searchparameter> spar = new ArrayList<searchparameter>();
        List<person> l= legacyPerson.search(spar);
        return AssembleResources(l);

    }

  

  
}
