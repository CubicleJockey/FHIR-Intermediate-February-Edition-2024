package org.hl7.fhir.fic.legacy.model;

public class personidentifier {
    private int prsn_id;
	private int identifier_type_id;
    private String identifier_value;
    
    
	public int getPersonId() { return prsn_id; }
	public int getIdentifierId() { return identifier_type_id; }
	public String getIdentifierValue() { return identifier_value; }
	
	public personidentifier(int PersonId, int identifierId, String value) {

		prsn_id=PersonId;
        identifier_type_id=identifierId;
        identifier_value=value;
        
    }
}
