package org.hl7.fhir.fic.legacy.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

public class config {
    //private static final Logger LOGGER = LoggerFactory.getLogger( config.class);
  
    private String GetPropertyValue(String propertyName,String defaultValue)
    {
        Properties prop = new Properties();
        String fileName = "legacy.config";
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
        if (inputStream != null)
            try {
                prop.load(inputStream);
            } catch (IOException e) {
                return defaultValue;    
            }
            return prop.getProperty(propertyName);
     }
  
     public String Url()
    {
        return GetPropertyValue("url", "http://3.221.164.25:9080");
    }
    public String IdentifierUri()
    {
        return GetPropertyValue("identifier_uri", "http://identifier.uri.not.configured");
    }
}
