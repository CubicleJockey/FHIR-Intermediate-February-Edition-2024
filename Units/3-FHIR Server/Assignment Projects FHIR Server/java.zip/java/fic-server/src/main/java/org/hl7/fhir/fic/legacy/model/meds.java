package org.hl7.fhir.fic.legacy.model;

public class meds {
    private String yes ="yes";
    private String code;
	private String display;
    private String opioid;
    public String getCode()     { return code; }
    public String getDisplay()  { return display; }
	public Boolean isOpioid()    { return (opioid.equals(yes)); }
    
    public meds( String Code,String Display, String Opioid)
    {
        code=Code;
        display=Display;
        opioid=Opioid;
        
    } 
}

