# FHIR Intermediate Course / Unit 3 - Servers / Java

Loosely based in the HAPI FHIR Plain Server Skeleton ( a good place to start if you are just beginning to build servers based in FHIR HAPI)

[https://hapifhir.io/hapi-fhir/docs/server_plain/get_started.html](https://hapifhir.io/hapi-fhir/docs/server_plain/get_started.html)

To begin:

* Run the following command to compile the project and start a local testing server that runs it:

```
mvn jetty:run
```

* This server implements a FHIR facade to a proprietary API based on Postgrest with three endpoints for 'Person' information, and two endpoints for 'Medication' information

  you can try the propietary facade from your browser or REST Client

  * http://3.221.164.25:9080/person
  * http://3.221.164.25:9080/identifier_type
  * http://3.221.164.25:9080/person_identifier
  * http://3.221.164.25:9080/meds
  * http://3.221.164.25:9080/rx
* Then you can test that your server is running by fetching its CapabilityStatement, getting some Patients using the PRSN_ID as the FHIR Patient Id.
* The Postman Collection allows you to test all the current capabilities

Support for the Patient facade is implemented in the class mapper.PatientResourceProvider. MedicationRequest facade is also implemented.

This classes communicates with the legacy API implemented in the legacy classes

## Rules

You cannot touch the classes under 'legacy'. They are...legacy.

## Assignments

[1] Add Search by Email / Telecom

The original API allows a very limited parameterized search for persons.

There is a Search Parameter for email in the legacy API, but it's not in the FHIR facade

a. You need to support FHIR search by email and telecom.

b. When searching by telecom, only email is accepted as system. If you receive any other you need to raise an exception

[2] Add Support for Practitioner

We need you to add Practitioner support to the same project, without ruining the Patient support and without touching the legacy classes

Hints:

1. Practitioners are persons who have an NPI identifier (system=...url.../NPI). All the others are Patients, are (legacy) persons, but they are not Practitioners
2. birthdate is not a standard search parameter for Practitioner
3. If you search all the Practitioners by ANY search parameter, all of them will have an NPI identifier
4. If you do a direct get to a Practitioner by ID, which is the same as the Patient / Person id, and the person is NOT a Practitioner, you need to return an exception
5. If you do a search by identifier for a Practitioner, the only valid system=...url.../NPI

[3] Fix the MedicationRequest resource

We need to fix MedicationRequest

1. Make it FHIR compliant.  There are some mandatory elements missing.
2. Add the element Requester.display with the full name of the referenced requesting Practitioner
3. Add a new dosageInstruction if the medication being ordered is an opioid (The legacy API provides a function called IsOpioid( rxNormCode ) answering this question.
