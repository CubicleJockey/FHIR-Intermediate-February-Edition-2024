const ServerEndpoint = ()=> {
    return "http://localhost:3000/4_0_0/";
}
const StudentId= () => {
    return "kaminker.diego@gmail.com";
}
const AssignmentSubmissionFHIRServer = () => {
    return "http://fhirserver.hl7fundamentals.org/fhir";
}

const StudentName=()=>{
    return "Diego Kaminker";
}
const USCoreValidationServer = () => {
    return "http://wildfhir4.aegis.net/fhir4-0-1";
}

exports.ServerEndpoint=ServerEndpoint;
exports.AssignmentSubmissionFHIRServer=AssignmentSubmissionFHIRServer;
exports.StudentId=StudentId;
exports.StudentName=StudentName;
exports.USCoreValidationServer=USCoreValidationServer;