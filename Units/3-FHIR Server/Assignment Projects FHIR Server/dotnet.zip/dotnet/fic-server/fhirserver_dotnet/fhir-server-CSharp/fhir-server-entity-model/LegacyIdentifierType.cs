

namespace fhir_server_entity_model
{
    public class LegacyIdentifierType
    {
		public long identifier_type_id { get; set; }
		public string identifier_code { get; set; }
		public string identifier_desc { get; set; }
		public string identifier_create_date { get; set; }
		}
}
