

namespace fhir_server_entity_model
{
    public class LegacyMed
    {
		public string code { get; set; }
		public string display { get; set; }
		public string opioid { get; set; }
		}
}
