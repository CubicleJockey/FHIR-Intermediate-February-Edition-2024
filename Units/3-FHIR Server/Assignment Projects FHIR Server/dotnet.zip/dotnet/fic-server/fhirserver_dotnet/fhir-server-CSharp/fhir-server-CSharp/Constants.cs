﻿using System;
using System.Collections.Generic;
using System.Text;

namespace fhir_server_CSharp
{
    internal static class Constants
    {
        internal const string HTTPPROTOCOL = "http";
        internal const string MIMETYPE_JSON = "application/json";
        
    }
}
