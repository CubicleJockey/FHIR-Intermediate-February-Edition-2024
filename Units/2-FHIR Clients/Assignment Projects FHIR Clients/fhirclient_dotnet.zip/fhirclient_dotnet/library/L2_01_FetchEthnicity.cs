using System;
using Hl7.Fhir.Model;  
using Hl7.Fhir.Rest;

namespace fhirclient_dotnet
{
    public class FetchEthnicity
    {
        public string GetEthnicity
        (string ServerEndPoint,
         string IdentifierSystem,
         string IdentifierValue
         )
         {
             String aux="";
             return aux;

                    }
        
    }
}
