using System;
using Hl7.Fhir.Model;  
using Hl7.Fhir.Rest;

namespace fhirclient_dotnet
{
    public class FetchMedication
    {
        public string GetMedications
        (string ServerEndPoint,
         string IdentifierSystem,
         string IdentifierValue
         )
         {
             String aux="";
             return aux;
             
         }        
    }
}
