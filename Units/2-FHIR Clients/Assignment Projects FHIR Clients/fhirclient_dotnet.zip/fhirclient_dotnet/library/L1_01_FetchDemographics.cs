﻿using System;
using Hl7.Fhir.Model;  
using Hl7.Fhir.Rest;

namespace fhirclient_dotnet
{
    public class FetchDemographics
    {
        public string GetPatientPhoneAndEmail
        (string ServerEndPoint,
         string IdentifierSystem,
         string IdentifierValue)
         {
            String aux="";
            return aux;
            
         }
    
    }
}
