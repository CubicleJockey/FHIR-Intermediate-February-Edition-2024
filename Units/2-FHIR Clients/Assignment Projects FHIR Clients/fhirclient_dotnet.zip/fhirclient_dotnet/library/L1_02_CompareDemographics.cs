using System;
using Hl7.Fhir.Model;  
using Hl7.Fhir.Rest;

namespace fhirclient_dotnet
{
    public class CompareDemographics
    {
        public string GetDemographicComparison
        (string ServerEndPoint,
         string IdentifierSystem,
         string IdentifierValue,
         string myFamily,
         string myGiven,
         string myGender,
         string myBirthDate
         )
         {
            string aux="";
            return aux;
         }
    }
}
