package com.fhirintcourse.u2;

public class L04_2_CreateUSCoreImmunization {

    public String CreateUSCoreR4Immunization
    (  
    String ServerEndPoint,
    String IdentifierSystem,
    String IdentifierValue,
    String ImmunizationStatusCode,
    String ImmunizationDateTime,
    String ProductCVXCode,
    String ProductCVXDisplay,
    String ReasonCode)
    
    {       
        String aux="";
        return aux;  
    }
         






}
