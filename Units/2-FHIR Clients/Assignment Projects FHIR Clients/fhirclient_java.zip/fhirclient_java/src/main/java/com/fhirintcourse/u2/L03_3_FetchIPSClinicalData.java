package com.fhirintcourse.u2;


public class L03_3_FetchIPSClinicalData {

    public String GetIPSMedications(String ServerEndPoint, String IdentifierSystem, String IdentifierValue)
         {
            String aux="";
            return aux;
 
        }


    public String GetIPSImmunizations(String ServerEndPoint, String IdentifierSystem, String IdentifierValue)
    {
    String aux="";
    return aux;
    }


}


