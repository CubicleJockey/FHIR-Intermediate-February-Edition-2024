package com.fhirintcourse.u2;


public class L01_2_CompareDemographics {


    public String GetDemographicComparison(String ServerEndPoint, String IdentifierSystem,String IdentifierValue,
    String myFamily,String myGiven,String myGender,String myBirth)
    
    {
        String aux="";
        return aux;
    }
        
}


