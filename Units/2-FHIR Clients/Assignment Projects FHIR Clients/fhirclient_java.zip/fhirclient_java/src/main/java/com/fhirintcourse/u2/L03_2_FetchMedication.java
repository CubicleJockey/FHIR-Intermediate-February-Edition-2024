package com.fhirintcourse.u2;

public class L03_2_FetchMedication {

    public String GetMedications(String ServerEndPoint, String IdentifierSystem,String IdentifierValue)

    {
        String aux="";
        return aux;
    }        
}


