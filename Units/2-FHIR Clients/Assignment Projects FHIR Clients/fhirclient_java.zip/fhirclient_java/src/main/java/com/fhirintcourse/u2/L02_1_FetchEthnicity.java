package com.fhirintcourse.u2;

public class L02_1_FetchEthnicity {


    public String GetEthnicity(String ServerEndPoint, String IdentifierSystem,String IdentifierValue)

    {    
        String aux="";
        return aux;
    }
    
}