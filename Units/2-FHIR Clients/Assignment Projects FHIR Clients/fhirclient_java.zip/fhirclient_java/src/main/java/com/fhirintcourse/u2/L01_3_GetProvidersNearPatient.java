package com.fhirintcourse.u2;

public class L01_3_GetProvidersNearPatient {


    public String GetProvidersNearCity(String ServerEndPoint, String IdentifierSystem,String IdentifierValue)
    {
       
        
        String aux="";
        return aux;  
    }

   }


