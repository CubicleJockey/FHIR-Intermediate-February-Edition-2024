package com.fhirintcourse.u2;

public class L03_1_FetchImmunization {

    public String GetImmunizations(String ServerEndPoint, String IdentifierSystem,String IdentifierValue)
    {
       
        String aux="";
        return aux;
    }
        
}


