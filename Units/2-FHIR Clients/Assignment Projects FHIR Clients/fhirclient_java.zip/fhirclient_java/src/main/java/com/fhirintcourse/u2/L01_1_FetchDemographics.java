package com.fhirintcourse.u2;


public class L01_1_FetchDemographics {


    public String GetPatientPhoneAndEmail(String ServerEndPoint, String IdentifierSystem,String IdentifierValue) 
    {
        String aux=""; 
        
        return aux;
    }
    
 }
