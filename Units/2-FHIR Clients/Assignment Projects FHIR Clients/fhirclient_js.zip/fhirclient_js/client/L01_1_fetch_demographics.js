const Client = require('fhir-kit-client');
module.exports={GetPatientPhoneAndEmail};


async function GetPatientPhoneAndEmail(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
       return aux;
            
    }
