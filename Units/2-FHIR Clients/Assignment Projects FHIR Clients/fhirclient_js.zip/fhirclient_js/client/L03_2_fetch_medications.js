const Client = require('fhir-kit-client');
module.exports={GetMedications};

async function GetMedications(server,patientidentifiersystem,patientidentifiervalue
    )
    {
       var aux=""; 
       return aux; 
    }    
